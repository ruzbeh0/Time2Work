declare module '*.scss';
declare module '*.css';
declare module '*.svg'; // we recommed using SVGs for all the icons and UI elements
declare module '*.png';
declare module '*.jpg';
declare module '*.gif';